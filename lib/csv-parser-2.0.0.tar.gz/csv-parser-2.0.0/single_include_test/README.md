# Purpose

The purpose of this directory is to make sure that the single header
`csv.hpp` file does not cause compile errors when `#include`d from multiple
.cpp files.